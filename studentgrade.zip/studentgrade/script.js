
function calculateGrade() {

    // Get student name
    let name = document.getElementById("studentName").value;

    // Get subject marks
    let sub1 = Number(document.getElementById("subject1").value);
    let sub2 = Number(document.getElementById("subject2").value);
    let sub3 = Number(document.getElementById("subject3").value);
    let sub4 = Number(document.getElementById("subject4").value);
    let sub5 = Number(document.getElementById("subject5").value);

    // Check empty fields
    if (name === "" ||
        document.getElementById("subject1").value === "" ||
        document.getElementById("subject2").value === "" ||
        document.getElementById("subject3").value === "" ||
        document.getElementById("subject4").value === "" ||
        document.getElementById("subject5").value === "") {

        document.getElementById("result").innerText =
            "Please fill all fields!";

        return;
    }

    // Validate marks
    let marks = [sub1, sub2, sub3, sub4, sub5];

    if (marks.some(mark => mark < 0 || mark > 100)) {
        document.getElementById("result").innerText =
            "Marks must be between 0 and 100!";

        return;
    }

    // Calculate total and percentage
    let total = sub1 + sub2 + sub3 + sub4 + sub5;

    let percentage = (total / 500) * 100;

    // Calculate grade
    let grade;

    if (percentage >= 80) {
        grade = "A";
    }
    else if (percentage >= 70) {
        grade = "B";
    }
    else if (percentage >= 60) {
        grade = "C";
    }
    else if (percentage >= 50) {
        grade = "D";
    }
    else {
        grade = "F";
    }

    // Pass or Fail
    let status;

    if (marks.every(mark => mark >= 40)) {
        status = "Pass";
    }
    else {
        status = "Fail";
    }

    // Display result
    document.getElementById("result").innerHTML =
        "Student Name: " + name + "<br>" +
        "Total Marks: " + total + "/500" + "<br>" +
        "Percentage: " + percentage.toFixed(2) + "%" + "<br>" +
        "Grade: " + grade + "<br>" +
        "Status: " + status;
}